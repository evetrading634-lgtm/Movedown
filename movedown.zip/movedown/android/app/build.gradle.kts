plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.movedown.store"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.movedown.store"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        // >>> CHANGE THIS to your deployed backend URL (keep the trailing slash).
        // Android emulator talking to a backend on your PC: "http://10.0.2.2:3000/"
        buildConfigField("String", "BASE_URL", "\"https://YOUR-SERVER.example.com/\"")
    }

    buildTypes {
        debug {
            manifestPlaceholders["usesCleartext"] = "true"   // lets you test with http:// locally
        }
        release {
            isMinifyEnabled = false
            manifestPlaceholders["usesCleartext"] = "false"  // production must use https://
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("io.coil-kt:coil-compose:2.7.0")
}
