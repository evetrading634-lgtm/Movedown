package com.movedown.store

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.movedown.store.ui.MoveDownTheme
import com.movedown.store.ui.StoreRoot

class MainActivity : ComponentActivity() {
    private val viewModel: StoreViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MoveDownTheme {
                StoreRoot(viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // After the system installer closes, update Install / Update / Open buttons.
        viewModel.refreshInstalled()
    }
}
