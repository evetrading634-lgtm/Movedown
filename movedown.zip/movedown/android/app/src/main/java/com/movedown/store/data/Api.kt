package com.movedown.store.data

import com.movedown.store.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Talks to the MoveDown backend. No API key is needed – the catalog is public. */
object Api {
    private val base = BuildConfig.BASE_URL.trimEnd('/')

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun listApps(query: String = ""): List<StoreApp> = withContext(Dispatchers.IO) {
        val url = "$base/api/apps".toHttpUrl().newBuilder().apply {
            if (query.isNotBlank()) addQueryParameter("q", query.trim())
        }.build()

        client.newCall(Request.Builder().url(url).build()).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Server error (${response.code})")
            val json = JSONArray(response.body?.string() ?: "[]")
            List(json.length()) { parse(json.getJSONObject(it)) }
        }
    }

    /** Downloads [url] into [dest]. [onProgress] gets values 0f..1f (only when the size is known). */
    suspend fun download(url: String, dest: File, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".part")
        try {
            client.newCall(Request.Builder().url(url).build()).execute().use { response ->
                if (!response.isSuccessful) throw IOException("Download failed (${response.code})")
                val body = response.body ?: throw IOException("Empty response")
                val total = body.contentLength()
                var done = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tmp.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            ensureActive()
                            val n = input.read(buffer)
                            if (n < 0) break
                            output.write(buffer, 0, n)
                            done += n
                            if (total > 0) {
                                val percent = (done * 100 / total).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent / 100f)
                                }
                            }
                        }
                    }
                }
            }
            if (!tmp.renameTo(dest)) throw IOException("Could not save the file")
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    private fun parse(o: JSONObject) = StoreApp(
        id = o.getString("id"),
        name = o.getString("name"),
        packageName = o.getString("packageName"),
        versionName = o.getString("versionName"),
        versionCode = o.getLong("versionCode"),
        description = o.optString("description", ""),
        sizeBytes = o.optLong("sizeBytes", 0),
        downloads = o.optInt("downloads", 0),
        iconUrl = if (o.isNull("iconPath")) null else base + o.getString("iconPath"),
        downloadUrl = base + o.getString("downloadPath"),
    )
}
