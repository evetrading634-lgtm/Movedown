package com.movedown.store.data

data class StoreApp(
    val id: String,
    val name: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val description: String,
    val sizeBytes: Long,
    val downloads: Int,
    val iconUrl: String?,
    val downloadUrl: String,
)
