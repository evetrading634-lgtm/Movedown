# MoveDown

Free, Play Store–style app store for **your own apps only**.
Anyone can browse and download your apps – **no API key, no login**. Only you can upload (admin password).

```
movedown/
├── backend/            Node.js (Express) server – catalog API, APK storage, admin page
│   ├── src/            server.js, store.js, config.js
│   ├── public/         admin.html  (upload page: /admin)
│   ├── uploads/        APKs + icons (created automatically)
│   └── data/           apps.json  (catalog)
└── android/            Kotlin + Jetpack Compose app (the store itself)
    └── app/src/main/java/com/movedown/store/
        ├── MainActivity.kt, StoreViewModel.kt
        ├── data/       Api.kt, Models.kt
        ├── install/    Installer.kt
        └── ui/         Theme.kt, StoreScreens.kt
```

## 1) Backend
```bash
cd backend
npm install
ADMIN_PASSWORD="long-random-password" npm start    # http://localhost:3000
```
- Open `/admin`, type the admin password, upload your APK (+ icon, name, package name, version name, version code).
- To release an update: upload again with the **same package name** and a **higher version code**.
- Deploy anywhere that runs Node 18+ (Render, Railway, Fly.io, a VPS, Termux). Use **HTTPS**.
- Free hosts often wipe the disk on restart – attach a persistent disk and set `DATA_DIR` and `UPLOAD_DIR` to it.

## 2) Android app
1. Open the `android/` folder in Android Studio (let it sync Gradle).
2. In `app/build.gradle.kts` set `BASE_URL` to your server (keep the trailing `/`).
   Emulator + backend on your PC: `http://10.0.2.2:3000/`
3. Run on your phone, or Build > Generate Signed App Bundle / APK for a release APK.
4. Share the MoveDown APK with people. On first install they must allow "Install unknown apps" for MoveDown.

## Notes
- Your apps must be signed; updates must use the same signing key as the installed version.
- The upload API is the only protected part (`x-admin-password` header). Downloads are open to everyone.
