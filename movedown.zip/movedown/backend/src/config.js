import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export const PORT = Number(process.env.PORT || 3000);
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
export const MAX_APK_MB = Number(process.env.MAX_APK_MB || 200);
export const DATA_DIR = process.env.DATA_DIR || path.join(root, 'data');
export const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(root, 'uploads');
export const PUBLIC_DIR = path.join(root, 'public');

for (const dir of [DATA_DIR, path.join(UPLOAD_DIR, 'apk'), path.join(UPLOAD_DIR, 'icons')]) {
  fs.mkdirSync(dir, { recursive: true });
}
