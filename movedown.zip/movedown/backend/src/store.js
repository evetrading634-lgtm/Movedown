// Tiny JSON-file "database" – enough for a personal store, no native modules needed.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DATA_DIR } from './config.js';

const FILE = path.join(DATA_DIR, 'apps.json');
let apps = [];
try {
  apps = JSON.parse(fs.readFileSync(FILE, 'utf8'));
} catch {
  apps = [];
}

function save() {
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(apps, null, 2));
  fs.renameSync(tmp, FILE);
}

export const list = () => apps;
export const get = (id) => apps.find((a) => a.id === id);

export function create(data) {
  const now = Date.now();
  const app = { id: crypto.randomUUID(), downloads: 0, createdAt: now, updatedAt: now, ...data };
  apps.push(app);
  save();
  return app;
}

export function update(id, patch) {
  const app = get(id);
  if (!app) return null;
  Object.assign(app, patch, { updatedAt: Date.now() });
  save();
  return app;
}

export function bumpDownloads(id) {
  const app = get(id);
  if (!app) return;
  app.downloads += 1;
  save();
}

export function remove(id) {
  const i = apps.findIndex((a) => a.id === id);
  if (i < 0) return null;
  const [removed] = apps.splice(i, 1);
  save();
  return removed;
}
