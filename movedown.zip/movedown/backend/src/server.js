import express from 'express';
import cors from 'cors';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import * as cfg from './config.js';
import * as store from './store.js';

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', true);
app.use(cors());
app.use(express.json());

/* ---------- helpers ---------- */

const APK_DIR = path.join(cfg.UPLOAD_DIR, 'apk');
const ICON_DIR = path.join(cfg.UPLOAD_DIR, 'icons');
const PACKAGE_RE = /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/;

const rm = (p) => fs.promises.unlink(p).catch(() => {});
const cleanup = (files) => Object.values(files || {}).flat().forEach((f) => rm(f.path));

const toPublic = (a) => ({
  id: a.id,
  name: a.name,
  packageName: a.packageName,
  versionName: a.versionName,
  versionCode: a.versionCode,
  description: a.description,
  sizeBytes: a.sizeBytes,
  downloads: a.downloads,
  iconPath: a.icon ? `/files/icons/${a.icon}` : null,
  downloadPath: `/api/apps/${a.id}/download`,
  updatedAt: a.updatedAt,
});

/* ---------- admin auth (ONLY for uploading; downloads need no key) ---------- */

const fails = new Map(); // ip -> { count, first }
function requireAdmin(req, res, next) {
  if (!cfg.ADMIN_PASSWORD) {
    return res.status(503).json({ error: 'Admin disabled. Set the ADMIN_PASSWORD environment variable.' });
  }
  const f = fails.get(req.ip);
  if (f && f.count >= 10 && Date.now() - f.first < 15 * 60 * 1000) {
    return res.status(429).json({ error: 'Too many wrong attempts. Try again later.' });
  }
  const given = Buffer.from(String(req.get('x-admin-password') || ''));
  const real = Buffer.from(cfg.ADMIN_PASSWORD);
  const ok = given.length === real.length && crypto.timingSafeEqual(given, real);
  if (!ok) {
    const now = Date.now();
    if (!f || now - f.first >= 15 * 60 * 1000) fails.set(req.ip, { count: 1, first: now });
    else f.count += 1;
    return res.status(401).json({ error: 'Wrong password' });
  }
  fails.delete(req.ip);
  next();
}

/* ---------- uploads ---------- */

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, file.fieldname === 'apk' ? APK_DIR : ICON_DIR),
    filename: (req, file, cb) => {
      if (file.fieldname === 'apk') return cb(null, crypto.randomUUID() + '.apk');
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, crypto.randomUUID() + (['.png', '.jpg', '.jpeg', '.webp'].includes(ext) ? ext : '.png'));
    },
  }),
  limits: { fileSize: cfg.MAX_APK_MB * 1024 * 1024, files: 2 },
  fileFilter: (req, file, cb) => {
    if (file.fieldname === 'apk' && path.extname(file.originalname).toLowerCase() === '.apk') return cb(null, true);
    if (file.fieldname === 'icon' && file.mimetype.startsWith('image/')) return cb(null, true);
    cb(new Error('Invalid file: "apk" must be a .apk and "icon" must be an image'));
  },
}).fields([
  { name: 'apk', maxCount: 1 },
  { name: 'icon', maxCount: 1 },
]);

/* ---------- public API (no key needed) ---------- */

app.get('/', (req, res) => res.json({ name: 'MoveDown', apps: store.list().length }));
app.get('/health', (req, res) => res.json({ ok: true }));

app.get('/api/apps', (req, res) => {
  const q = String(req.query.q || '').toLowerCase().trim();
  let items = store.list();
  if (q) {
    items = items.filter(
      (a) => a.name.toLowerCase().includes(q) || (a.description || '').toLowerCase().includes(q),
    );
  }
  res.json([...items].sort((a, b) => b.updatedAt - a.updatedAt).map(toPublic));
});

app.get('/api/apps/:id', (req, res) => {
  const a = store.get(req.params.id);
  if (!a) return res.status(404).json({ error: 'Not found' });
  res.json(toPublic(a));
});

app.get('/api/apps/:id/download', (req, res) => {
  const a = store.get(req.params.id);
  if (!a) return res.status(404).json({ error: 'Not found' });
  const file = path.join(APK_DIR, a.apk);
  if (!fs.existsSync(file)) return res.status(404).json({ error: 'APK file missing' });
  if (!req.headers.range) store.bumpDownloads(a.id);
  const safe = a.name.replace(/[^\w.-]+/g, '_');
  res.type('application/vnd.android.package-archive');
  res.download(file, `${safe}-${a.versionName}.apk`);
});

app.use('/files/icons', express.static(ICON_DIR, { maxAge: '7d' }));

/* ---------- admin API + page ---------- */

app.get('/admin', (req, res) => res.sendFile(path.join(cfg.PUBLIC_DIR, 'admin.html')));

app.post('/api/admin/apps', requireAdmin, upload, (req, res) => {
  const { name, packageName, versionName, versionCode, description } = req.body;
  const apk = req.files?.apk?.[0];
  const icon = req.files?.icon?.[0];

  if (!apk || !name || !versionName || !PACKAGE_RE.test(packageName || '') || !Number.isInteger(Number(versionCode))) {
    cleanup(req.files);
    return res.status(400).json({ error: 'Need: name, valid packageName, versionName, versionCode (integer) and apk file' });
  }
  if (store.list().some((a) => a.packageName === packageName)) {
    cleanup(req.files);
    return res.status(409).json({ error: 'This packageName already exists – update it instead' });
  }
  const created = store.create({
    name,
    packageName,
    versionName,
    versionCode: Number(versionCode),
    description: description || '',
    apk: apk.filename,
    icon: icon ? icon.filename : null,
    sizeBytes: apk.size,
  });
  res.status(201).json(toPublic(created));
});

app.put('/api/admin/apps/:id', requireAdmin, upload, (req, res) => {
  const a = store.get(req.params.id);
  if (!a) {
    cleanup(req.files);
    return res.status(404).json({ error: 'Not found' });
  }
  const b = req.body;
  const patch = {};
  for (const k of ['name', 'description', 'versionName']) if (b[k]) patch[k] = b[k];
  if (b.versionCode) {
    if (!Number.isInteger(Number(b.versionCode))) {
      cleanup(req.files);
      return res.status(400).json({ error: 'versionCode must be an integer' });
    }
    patch.versionCode = Number(b.versionCode);
  }
  const apk = req.files?.apk?.[0];
  const icon = req.files?.icon?.[0];
  const oldFiles = [];
  if (apk) {
    oldFiles.push(path.join(APK_DIR, a.apk));
    patch.apk = apk.filename;
    patch.sizeBytes = apk.size;
  }
  if (icon) {
    if (a.icon) oldFiles.push(path.join(ICON_DIR, a.icon));
    patch.icon = icon.filename;
  }
  const updated = store.update(a.id, patch);
  oldFiles.forEach(rm);
  res.json(toPublic(updated));
});

app.delete('/api/admin/apps/:id', requireAdmin, (req, res) => {
  const removed = store.remove(req.params.id);
  if (!removed) return res.status(404).json({ error: 'Not found' });
  rm(path.join(APK_DIR, removed.apk));
  if (removed.icon) rm(path.join(ICON_DIR, removed.icon));
  res.json({ ok: true });
});

/* ---------- errors ---------- */

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError || String(err?.message).startsWith('Invalid file')) {
    return res.status(400).json({ error: err.message });
  }
  console.error(err);
  res.status(500).json({ error: 'Server error' });
});

app.listen(cfg.PORT, () => {
  console.log(`MoveDown backend running on port ${cfg.PORT}`);
  if (!cfg.ADMIN_PASSWORD) console.warn('WARNING: ADMIN_PASSWORD is not set – uploading is disabled.');
});
